﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KeithleyInstruments.KeithleyDMM6500.Interop;

namespace DAQ6510_7707_DIO_Control_with_IVI_Driver
{
    class Program
    {

        static void Main(string[] args)
        {
            KeithleyDMM6500 daq6510 = new KeithleyDMM6500();
            daq6510.Initialize("TCPIP0::192.168.1.165::inst0::INSTR", true, false, "");
            string id = daq6510.Identity.InstrumentModel;

            Console.WriteLine("ID is {0}", id);
            // Configure the 8-bit wide channel 111 for output
            daq6510.Route.ChannelConfiguration.Mode["111"] = KeithleyDMM6500ChannelModeEnum.KeithleyDMM6500ChannelModeOutput;
            daq6510.Route.ChannelConfiguration.Width["111"] = 1;
            // Write the bit pattern 1010 0101 (xA5)
            daq6510.Route.ChannelConfiguration.Write("111", 165);
            // Write the bit pattern 1111 1111 (xFF)
            daq6510.Route.ChannelConfiguration.Write("111", 255);
            // Write the bit pattern 0000 0000 (x00)
            daq6510.Route.ChannelConfiguration.Write("111", 0);

            daq6510.Close();
        }
    }
}
